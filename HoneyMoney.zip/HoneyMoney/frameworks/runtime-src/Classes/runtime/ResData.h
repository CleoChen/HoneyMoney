#ifndef  _RESDATA__H_
#define  _RESDATA__H_

extern const unsigned char __shinePngData[11776];
extern const unsigned char __portraitPngData[122214];
extern const unsigned char __playEnablePngData[20254];
extern const unsigned char __landscapePngData[115832];

#endif // _RESDATA__H_