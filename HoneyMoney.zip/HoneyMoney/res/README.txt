
The file "fonts/arial.ttf" is used only in project of wp8. You can delete it in other projects.

