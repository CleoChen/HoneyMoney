
local CoinItem = class("CoinItem", function(x, y, coinIndex)
	local coinValue = {100, 5, 10, 50, 1}
	coinIndex = coinIndex or math.round(math.random()* 100 ) % 5 + 1
	local sprite = display.newSprite("#coin" .. coinValue[coinIndex] .. '.png')

	sprite.coinIndex = coinIndex
	sprite.x = x
	sprite.y = y
	sprite.isActive = false
	return sprite
end)

function CoinItem:ctor()
end

function CoinItem:setActive(active)
    self.isActive = active

    local frame
    if (active) then
        frame = display.newSpriteFrame("coin"  .. self.coinIndex .. '_s.png')
    else
        frame = display.newSpriteFrame("coin"  .. self.coinIndex .. '.png')
    end

    self:setSpriteFrame(frame)

    if (active) then
        self:stopAllActions()
        local scaleTo1 = cc.ScaleTo:create(0.1, 1.1)
        local scaleTo2 = cc.ScaleTo:create(0.05, 1.0)
        self:runAction(cc.Sequence:create(scaleTo1, scaleTo2))
    end
end

function CoinItem.getWidth()
    g_coinWidth = 0
    if (0 == g_coinWidth) then
        local sprite = display.newSprite("#coin1.png")
        g_coinWidth = sprite:getContentSize().width
    end
    return g_coinWidth
end

return CoinItem
