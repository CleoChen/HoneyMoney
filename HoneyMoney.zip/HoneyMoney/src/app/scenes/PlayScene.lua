CoinItem = import("app.scenes.CoinItem")

local PlayScene = class("PlayScene", function()
    return display.newScene("PlayScene")
end)

function PlayScene:ctor()

	--值的初始化
	self.curScore = 0
	self.highestScore = 123

	self.xCount = 10-- 水平方向金币数
	self.yCount = 8 -- 垂直方向金币数
	self.yCountMax = 12
	self.coinGap = 0 -- 水果间距

	self:initUI()

	-- 初始化随机数
	math.newrandomseed()

	--  计算水果矩阵左下角的x、y坐标：以矩阵中点对齐屏幕中点来计算，然后再做Y轴修正。
	self.matrixLBX = (display.width - CoinItem.getWidth() * self.xCount - (self.yCount - 1) * self.coinGap) / 2
	self.matrixLBY = display.top  --CoinItem.getWidth() * self.yCount - (self.xCount - 1) * self.coinGap) / 2 
	- 1100

	-- 等待转场特效结束后再加载矩阵
	self:addNodeEventListener(cc.NODE_EVENT, function(event)
		if event.name == "enterTransitionFinish" then
			self:initMartix()
		end
	end)
end
function PlayScene:initUI()
	-- 加载背景图片
	display.newSprite("playBG.png")
		:pos(display.cx, display.cy)
		:addTo(self)
	
	--当前分数图片
	local curScore = display.newSprite("#score.png")
		:pos(display.left + 100, display.top - 80)
		:addTo(self)

	self.curScoreLabel = cc.ui.UILabel.new({UILabelType = 1, text = tostring(self.curScore), font = "font/scores_Upper.fnt"})
		:align(display.CENTER, display.left + 200, display.top - 80)
        :addTo(self)

	--历史最高分图片
	local highestScore = display.newSprite("#record.png")
		:pos(display.left + 500, display.top - 80)
		:addTo(self)

	self.highestScoreLabel = cc.ui.UILabel.new({UILabelType = 1, text = tostring(self.highestScore), font = "font/scores_Upper.fnt"})
		:align(display.CENTER, display.left + 620, display.top - 80)
        :addTo(self)

    --设置按钮
	cc.ui.UIPushButton.new("#setting.png", {scale9 = false})
		:onButtonClicked( function(event)
				print("TODO:给老子暂停！")
				end)	
		:align(display.CENTER, display.left + 950, display.top - 80)
		:addTo(self)
end

function PlayScene:initMartix()
	-- 创建空矩阵
	self.matrix = {}
	for y = 1, self.yCount do
		for x = 1, self.xCount do
			if 1 == y and 2 == x then
                -- 确保有可消除的金币
                self:createAndDropCoin(x, y, self.matrix[1].coinIndex)
            else 
                self:createAndDropCoin(x, y)
			end
		end
	end
end

function PlayScene:createAndDropCoin(x, y, coinIndex)
    local newCoin = CoinItem.new(x, y, coinIndex)
    local endPosition = self:positionOfCoin(x, y)
    local startPosition = cc.p(endPosition.x, endPosition.y + display.height / 2)
    newCoin:setPosition(startPosition)
    local speed = startPosition.y / (2 * display.height)
    newCoin:runAction(cc.MoveTo:create(speed, endPosition))
    self.matrix[(y - 1) * self.xCount + x] = newCoin
    self:addChild(newCoin)
end

function PlayScene:positionOfCoin(x, y)
    local px = self.matrixLBX + (CoinItem.getWidth() + self.coinGap) * (x - 1) + CoinItem.getWidth() / 3
    local py = self.matrixLBY + (CoinItem.getWidth() + self.coinGap) * (y - 1) + CoinItem.getWidth() / 3
    return cc.p(px, py)
end


function PlayScene:onEnter()
end

function PlayScene:onExit()
end

return PlayScene
